# Classifier Options
# --nolist
# Do not print out filenames and predicted response

# -- info
# Prints out accuracy, precision, recall, and f-score

# Commands to run
python3 training.py Training/ movietraining.nb
python3 test_splitter.py
python3 classifier.py movietraining.nb Testing/ --info

